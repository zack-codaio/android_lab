package ssuimobile.gameengine.action;


/**
 *
 */
public class GetDragFocusAction extends FSMAction {

	/**
	 */
	public GetDragFocusAction() {
		super(FSMActionType.GET_DRAG_FOCUS);
	}
}
