/** Automatically generated file. DO NOT MODIFY */
package edu.cmu.zaman.calculatorlab1luna;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}