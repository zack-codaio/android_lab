Sources used:
- android developer website
- stack overflow

Notes:
- everything specified works
- did not do any bells and whistles
