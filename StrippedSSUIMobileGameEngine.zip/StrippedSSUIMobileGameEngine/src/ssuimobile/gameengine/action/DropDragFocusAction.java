package ssuimobile.gameengine.action;


/**
 *
 */
public class DropDragFocusAction extends FSMAction {

	/**
	 */
	public DropDragFocusAction() {
		super(FSMActionType.DROP_DRAG_FOCUS);
	}

}
