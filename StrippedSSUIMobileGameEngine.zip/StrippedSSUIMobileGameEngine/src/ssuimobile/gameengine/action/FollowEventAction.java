package ssuimobile.gameengine.action;


/**
 *
 */
public class FollowEventAction extends FSMAction {

	/**
	 */
	public FollowEventAction() {
		super(FSMActionType.FOLLOW_EVENT_POSITION);
	}
}
