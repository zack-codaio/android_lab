/** Automatically generated file. DO NOT MODIFY */
package ssuimobile.gameengine;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}